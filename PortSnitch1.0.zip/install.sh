#!/bin/sh

echo "hello"
echo "welcome to Port_Snitch 1.0 installation!"

if [ ! -d ~/.conky ];then
        echo "There is no .conky directory in home..."
        echo "making directory .conky..."
        mkdir .conky 
 else   
 echo "directory <<~/.conky>> Found..."
   
if [ -d port_snitch ];then
        echo "port_snitch directory Found..."
        echo "copying Files..."
        sleep 2
        mkdir ~/.conky/port_snitch
        cp -r port_snitch ~/.conky/



        echo "all files copied successfully..."
        echo "Dont forget to grant run permissions to scripts/sys.sh (sudo chmod +x)"
        echo "would you open conky manager? [y or n]"
        read answer
        if [ "$answer" == "y" ] ;then 
        conky-manager2
        fi
        if [ "$answer" == "n" ] ;then
        sleep 5
	killall conky
	conky -c ~/.conky/port_snitch/connections
	conky -c ~/.conky/port_snitch/portz
        exit
    else
        echo "port_snitch directory Not Found..."
        echo "visit https://github.com/Logicboxxx/port_snitch and download it..."
        exit    
  fi        
fi
fi

