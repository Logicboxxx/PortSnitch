﻿								      Port Snitch  V1.0
									By: Logicbox

 		Thanks for checking out port snitch. A simple conky that monitors connections and ports for you. In the future I would like to make this much 
 	more advanced, one thing I would like to do is add monitoring for ports scans performed on the system this is on, monitor privileged ports and 
 	play audio file upon access request to any of them, and some other things. Any feed back would be greatly appreciated.
	Anyway this conky does not require a lot of dependencies to run right, The two that it does require you most likely already have installed.
	
    							• Nmap sudo apt-get install nmap
    							• netstat sudo apt-get install net-tools
      
		Since this is basically two separate conky's I have included an install bash script but personally I highly recommend using conky-manager2. To
        use the installation script first open a terminal in the directory the port_snitch folder was unzipped to and type "sudo chmod +x install.sh"
        to grant the script run permissions, then just type "bash install.sh" in the directory with the script. however i highly recommend using conky-manager2 
        to manage all your conky themes. It is honestly the best method for conky themes, makes life so much easier! 
        	You can clone this repository below to get conky-manager2 
	
	https://github.com/zcot/conky-manager2.git
	
	or visit the github at:
	
	https://github.com/zcot/conky-manager2
	
		If you'd like to contact me feel free to e-mail me at logicbox@tuta.io or logicbox@null.net
		keep posted with new products at my github:
		https://github.com/Logicboxxx
	Buy me a coffee 
		buymeacoffee.com/logicbox                
