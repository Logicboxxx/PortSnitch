#!/bin/bash
open_check() {
obtain=$(sudo nmap -n -PN -sT -sU -p- localhost)

open_ports=$(echo "$obtain" | grep -E "^[0-9]+/tcp" | awk '{print $1, "       \${alignr} " ,$3}')


if [ -n "$open_ports" ]; then
    echo "$open_ports"
else
    echo "No open ports found."
fi
}

listen_check() {
  LISTENPORTS=$(sudo netstat -tulnp 2>/dev/null | awk '/LISTEN/ {split($4,a,":"); print a[length(a)], $7}' | while read -r port program_pid; do
    pid=$(echo $program_pid | cut -d'/' -f1)
    program=$(echo $program_pid | cut -d'/' -f2)
    echo "$port \${alignr} $program / $pid"
  done | sort | uniq)
  echo "$LISTENPORTS"
}

command=$1
shift

case $command in
        open)
        open_check "$@"
        ;;
        listen)
        listen_check "$@"
        ;;
    *)
        exit 1
        ;;
esac
